﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace aula2.Models
{
    public class Estadoinformacao
    {
        public string Area_Km2 { get; set; }
        public string Codigo_Ibge { get; set; }
        public string Nome { get; set; }
    }
}
